#undef ABS
#define ABS(a) (((a) < 0) ? -(a) : (a))
